/*

 Name:           Eric Avery Birchard
 Instructor:     Dan Williams
 Assignment:     HomeWork Loops
 Date:           29, April 2015
 Class:          SDI
 Section:        1
 Term:           I



TODO: While loop
//sets up index
var b = 10;


//checks condition
while(b > 0){
    console.log(b + "Counting down:");

    //increments and/ or decrements
    b--;
}




//TODO: Do While Loop
var c = 10;

do{
    console.log(c + " Count down the do while:");
    c--;
}while(c > 0);



*/

//TODO: For Loop
//short hand combination

for(var i = 10; i > 0; i--){
    console.log(i + " i countdown")
}

